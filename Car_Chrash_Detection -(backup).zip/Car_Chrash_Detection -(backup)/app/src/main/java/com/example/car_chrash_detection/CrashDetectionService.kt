package com.example.car_chrash_detection

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.sqrt
import android.content.Context.RECEIVER_EXPORTED

class CrashDetectionService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var notificationManager: NotificationManager

    private var forceThreshold = 2.0f
    private var countdownSeconds = 15
    private var isAlertActive = false
    private var countdownHandler: Handler? = null
    private var countdownRunnable: Runnable? = null
    private var currentSeconds = countdownSeconds

    private val emergencyContacts = arrayOf("+9819191065", "+0987654321")
    private val emergencyMessage = "EMERGENCY: Vehicle crash detected! Location: "

    companion object {
        const val CHANNEL_ID = "CrashDetectionChannel"
        const val NOTIFICATION_ID = 1
    }

    private val cancelAlertReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "CANCEL_ALERT") {
                cancelAlert()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        mediaPlayer = MediaPlayer.create(this, alarmSound)
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
        }

        mediaPlayer?.isLooping = true

        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()

        // Register broadcast receiver with export flag for Android 13+
        val filter = IntentFilter("CANCEL_ALERT")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(cancelAlertReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(cancelAlertReceiver, filter)
        }

        try {
            startForeground(NOTIFICATION_ID, createNotification())
        } catch (e: SecurityException) {
            // Handle permission issues gracefully
            Toast.makeText(this, "Foreground service permission denied. Starting as normal service.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            // Handle other foreground service restrictions
            Toast.makeText(this, "Service started without foreground notification", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (it.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                val x = it.values[0]
                val y = it.values[1]
                val z = it.values[2]

                val gForce = sqrt((x * x + y * y + z * z).toDouble()).toFloat() / SensorManager.GRAVITY_EARTH

                updateForceInActivity(gForce)

                if (gForce > forceThreshold && !isAlertActive) {
                    triggerCrashAlert()
                }
            }
        }
    }

    private fun updateForceInActivity(force: Float) {
        val intent = Intent("UPDATE_FORCE")
        intent.putExtra("force", force)
        sendBroadcast(intent)
    }

    private fun triggerCrashAlert() {
        isAlertActive = true
        currentSeconds = countdownSeconds

        try {
            mediaPlayer?.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        showAlertInActivity()
        startCountdown()

        // Try to show notification, but don't crash if not allowed
        try {
            showAlertNotification()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startCountdown() {
        countdownHandler?.removeCallbacksAndMessages(null)
        countdownHandler = Handler(Looper.getMainLooper())
        countdownRunnable = object : Runnable {
            override fun run() {
                if (currentSeconds > 0) {
                    updateCountdownInActivity(currentSeconds)
                    currentSeconds--
                    countdownHandler?.postDelayed(this, 1000)
                } else {
                    sendEmergencyAlert()
                }
            }
        }
        countdownHandler?.post(countdownRunnable!!)
    }

    private fun updateCountdownInActivity(seconds: Int) {
        val intent = Intent("UPDATE_COUNTDOWN")
        intent.putExtra("seconds", seconds)
        sendBroadcast(intent)
    }

    private fun showAlertInActivity() {
        val intent = Intent("SHOW_ALERT")
        sendBroadcast(intent)
    }

    private fun cancelAlert() {
        isAlertActive = false
        try {
            mediaPlayer?.pause()
            mediaPlayer?.seekTo(0)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        countdownHandler?.removeCallbacksAndMessages(null)
        showNormalStatusInActivity()

        try {
            notificationManager.cancel(NOTIFICATION_ID + 1)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        Toast.makeText(this, "Alert cancelled", Toast.LENGTH_SHORT).show()
    }

    private fun showNormalStatusInActivity() {
        val intent = Intent("SHOW_NORMAL_STATUS")
        sendBroadcast(intent)
    }

    private fun sendEmergencyAlert() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.prepare()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val smsManager = SmsManager.getDefault()
        val location = getLastKnownLocation()

        for (contact in emergencyContacts) {
            try {
                smsManager.sendTextMessage(contact, null, emergencyMessage + location, null, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        Toast.makeText(this, "Emergency alert sent to contacts!", Toast.LENGTH_LONG).show()

        isAlertActive = false
        showNormalStatusInActivity()
    }

    private fun getLastKnownLocation(): String {
        return "Unknown location. Please check GPS."
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Crash Detection Service",
                NotificationManager.IMPORTANCE_LOW  // Changed to LOW to bypass restrictions
            ).apply {
                description = "Service that monitors for vehicle crashes"
            }
            notificationManager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Crash Detection Active")
            .setContentText("Monitoring for impacts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_LOW)  // Changed to LOW
            .setOngoing(true)
            .build()
    }

    private fun showAlertNotification() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🚨 CRASH DETECTED!")
            .setContentText("Emergency alert will be sent in $countdownSeconds seconds")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID + 1, notification)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)

        try {
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            unregisterReceiver(cancelAlertReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        countdownHandler?.removeCallbacksAndMessages(null)
    }
}