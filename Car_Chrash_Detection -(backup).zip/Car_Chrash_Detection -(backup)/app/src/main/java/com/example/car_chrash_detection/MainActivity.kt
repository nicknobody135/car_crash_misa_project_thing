package com.example.car_chrash_detection

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {

    private lateinit var forceTextView: TextView
    private lateinit var statusTextView: TextView
    private lateinit var countdownTextView: TextView
    private lateinit var startServiceButton: Button
    private lateinit var stopServiceButton: Button
    private lateinit var cancelAlertButton: Button

    companion object {
        const val REQUEST_CODE_PERMISSIONS = 100
        val REQUIRED_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.SEND_SMS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.SEND_SMS,
                Manifest.permission.CALL_PHONE
            )
        }
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "UPDATE_FORCE" -> {
                    val force = intent.getFloatExtra("force", 0f)
                    updateForceValue(force)
                }
                "UPDATE_COUNTDOWN" -> {
                    val seconds = intent.getIntExtra("seconds", 0)
                    updateCountdown(seconds)
                }
                "SHOW_ALERT" -> {
                    showAlertActive()
                }
                "SHOW_NORMAL_STATUS" -> {
                    showNormalStatus()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupClickListeners()
        checkPermissions()
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction("UPDATE_FORCE")
            addAction("UPDATE_COUNTDOWN")
            addAction("SHOW_ALERT")
            addAction("SHOW_NORMAL_STATUS")
        }

        // Fix for Android 13+ security requirement
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(updateReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(updateReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(updateReceiver)
    }

    private fun initViews() {
        forceTextView = findViewById(R.id.forceTextView)
        statusTextView = findViewById(R.id.statusTextView)
        countdownTextView = findViewById(R.id.countdownTextView)
        startServiceButton = findViewById(R.id.startServiceButton)
        stopServiceButton = findViewById(R.id.stopServiceButton)
        cancelAlertButton = findViewById(R.id.cancelAlertButton)
    }

    private fun setupClickListeners() {
        startServiceButton.setOnClickListener {
            startCrashDetectionService()
        }

        stopServiceButton.setOnClickListener {
            stopCrashDetectionService()
        }

        cancelAlertButton.setOnClickListener {
            cancelAlert()
        }
    }

    private fun checkPermissions() {
        val missingPermissions = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                missingPermissions.toTypedArray(),
                REQUEST_CODE_PERMISSIONS
            )
        } else {
            startCrashDetectionService()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                startCrashDetectionService()
            } else {
                Toast.makeText(
                    this,
                    "Permissions are required for crash detection to work",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun startCrashDetectionService() {
        val serviceIntent = Intent(this, CrashDetectionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        statusTextView.text = "Service: Running"
        statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
    }

    private fun stopCrashDetectionService() {
        val serviceIntent = Intent(this, CrashDetectionService::class.java)
        stopService(serviceIntent)
        statusTextView.text = "Service: Stopped"
        statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        forceTextView.text = "Force: 0.0 G"
        countdownTextView.text = ""
    }

    private fun cancelAlert() {
        val intent = Intent("CANCEL_ALERT")
        sendBroadcast(intent)
    }

    private fun updateForceValue(force: Float) {
        runOnUiThread {
            forceTextView.text = String.format("Force: %.2f G", force)
        }
    }

    private fun updateCountdown(seconds: Int) {
        runOnUiThread {
            countdownTextView.text = String.format("Alert in: %d seconds", seconds)
        }
    }

    private fun showAlertActive() {
        runOnUiThread {
            statusTextView.text = "Status: ALERT ACTIVE!"
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        }
    }

    private fun showNormalStatus() {
        runOnUiThread {
            statusTextView.text = "Status: Monitoring"
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            countdownTextView.text = ""
        }
    }
}